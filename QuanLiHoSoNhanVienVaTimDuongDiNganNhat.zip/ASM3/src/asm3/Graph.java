package asm3;

import java.util.ArrayList;
import java.util.Stack;

public class Graph {
    int[][] a;
    int n;

    Graph() {
        a = null;
        n = 0;
    }

    void clear() {
        a = null;
        n = 0;
    }

    void setData(int[][] b) {
        n = b.length;
        a = new int[n][n];
        int i, j;
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                a[i][j] = b[i][j];
    }

    void dispAdj() {
        int i, j;
        System.out.println("\nThe adjacency matrix:");
        for (i = 0; i < n; i++) {
            System.out.println();
            for (j = 0; j < n; j++)
                System.out.printf("%5d", a[i][j]);
        }
    }
    // DFS
    void DFS(int i) {
        Stack<Integer> stack = new Stack();
        // store passed city
        ArrayList<Integer> listVisit = new ArrayList();
        // mark passed city
        int[] visit = new int[n];
        // add city i at first
        visit[i] = 1;
        listVisit.add(i);
        stack.push(i);

        while (!stack.isEmpty()) {
            // count for checking when need to stop check || passed one city and start from the next city
            int count = 0;
            i = stack.peek();
            for (int j = 0; j < visit.length; j++) {
                // check and add city to passed city list
                if (a[i][j] > 0 && visit[j] == 0 && a[i][j] != 9999) {
                    listVisit.add(j);
                    visit[j] = 1;
                    stack.push(j);
                    break;
                } else {
                    //already passed one city
                    count++;
                }
            }
            //stop check and start again with next city
            if (count == visit.length) {
                stack.pop();
            }
        }
        // print
        for (int x : listVisit) {
            // quy uoc
            switch (x) {
                case 0:
                    System.out.print("A ");
                    break;
                case 1:
                    System.out.print("B ");
                    break;
                case 2: 
                    System.out.print("C ");
                    break;
                case 3:
                    System.out.print("D ");
                    break;
                case 4:
                    System.out.print("E ");
                    break;
                case 5:
                    System.out.print("F ");
                    break;
                case 6:
                    System.out.print("G ");
                    break;
            }
        }
    }
    // BFS
        void BFS(int i) {
            Stack<Integer> stack = new Stack<>();
            // store passed city
            ArrayList<Integer> listVisit = new ArrayList<>();
            // mark passed city
            int[] visit = new int[n];
            // add city i at first
            visit[i] = 1;
            listVisit.add(i);
            stack.push(i);
    
            while (!stack.isEmpty()) {
                //remove passed city
                int x = stack.pop();
                for (int j = 0; j < a.length; j++) {
                    if ((a[x][j] > 0 && visit[j] == 0 && a[x][j] != 9999)) {
                        stack.push(j);
                        visit[j] = 1;
                        listVisit.add(j);
                    }
                }
            }
            //print
            for (int x : listVisit) {
                switch (x) {
                    case 0:
                        System.out.print("A ");
                        break;
                    case 1:
                        System.out.print("B ");
                        break;
                    case 2:
                        System.out.print("C ");
                        break;
                    case 3:
                        System.out.print("D ");
                        break;
                    case 4:
                        System.out.print("E ");
                        break;
                    case 5:
                        System.out.print("F ");
                        break;
                    case 6:
                        System.out.print("G ");
                        break;
                }
            }
    
        }
     // Find the min distance
     int minDistance(int []dist, int[]BlackEnd){
         // min = 9999: y/c de bai
         //min_index = -1: check if null or not
        int min = 9999, min_index = -1, i;
        for(i = 0; i<n; i++){
            if(BlackEnd[i] == 0 && dist[i]<min){
                min = dist[i];
                min_index = i;
            }
        }
        return min == 9999?9999 : min_index;
    }
    // print the path
    void PrintPath(int []parent, int d){
        if(parent[d] == -1){
           // System.out.print(d);
            String s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            System.out.print(s1.charAt(d));
            return;
        }
        PrintPath(parent, parent[d]);
        String s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.print(" -> " + s1.charAt(d));
    }
    // print the length from the starting point to the point we want to set
    void PrintSolution(int dist[], int s, int d){
        System.out.println("The distance from " + s + " to " + d + " is " + dist[d]);
    }
    // dijkstra method
    void Dijkstra(int [][]a, int n, int s, int d){
        int i, u, j, count;
        int dist[] = new int[n];// save the weight of the matrix
        int BlackEnd[] = new int[n];// using to check if any vertexes are visited, assign = 1 else, assign = 0
        int lengthPath[] = new int[n];// count the path connecting between two vertexes
        int parent[] = new int[n];// save the sign (the path between two vertexes)
        parent[s] = -1;// initialize the path is null between tow vertexes is null
        for(i = 0; i<n; i++){
            dist[i] = 9999;// initialize the length between two vertexes in matrix are infinity
        }
        // assign the weight of the matrix is 0
        dist[s] = 0;
        for(count = 0; count<n-1; count++){
            // assign u = minDistance
            u = minDistance(dist, BlackEnd);
            if(u == 9999){
                break;
            }else{
                // mark as visited
                BlackEnd[u] = 1;
                for(j = 0; j<n; j++){
                    // check if the vertex is visited and some conditions
                    if (BlackEnd[j] == 0 && a[u][j] != 0 && dist[u] + a[u][j] < dist[j]) {
                        // save the path
                        parent[j] = u;
                        // count the vertex
                        lengthPath[j] = lengthPath[parent[j]] + 1;
                        // cong trong so khi di qua cac vertex
                        dist[j] = dist[u] + a[u][j];
                    } else if (BlackEnd[j] == 0 && a[u][j] != 0 && dist[u] + a[u][j] == dist[j]
                            && lengthPath[u] + 1 < lengthPath[j]) {
                        parent[j] = u;
                        lengthPath[j] = lengthPath[u] + 1;
                    }
                }
            }
        }
        // print the length
        PrintSolution(dist,s, d);
        // Printing the path
        if (dist[d] != 9999) {
            System.out.println("The path is: ");
            PrintPath(parent, d);
        } else
            System.out.println("There is not path between vertex " + s + " to vertex " + d);
    }
}
