package asm3;

import java.util.LinkedList;
import java.util.Queue;

public class MyBSTree {
    Node root;

    MyBSTree() {
        root = null;
    }

    // check if root is empty
    boolean isEmpty() {
        return root == null;
    }

    // insert to tree
    void Insert(Person p) {
        if (isEmpty()) {
            this.root = new Node(p);
        }
        root.insert(p);
    }

    // visit
    void Visit(Node p) {
        if (!p.isDeleted) {
            System.out.print(p.info + " ");
        }
    }

    // PreOrder Traverse
    void PreOrder(Node p) {
        if (p == null) {
            return;
        }
        Visit(p);
        PreOrder(p.left);
        PreOrder(p.right);
    }

    // InOrder Traverse
    void InOrder(Node p) {
        if (p == null) {
            return;
        }
        InOrder(p.left);
        Visit(p);
        InOrder(p.right);
    }

    // PostOrder Traverse
    void PostOrder(Node p) {
        if (p == null) {
            return;
        }
        PostOrder(p.left);
        PostOrder(p.right);
        Visit(p);
    }

    // BFS tree
    void Breadth() {
        // check if root is null
        if (root == null) {
            return;
        }
        // Using Queue to traverse
        Queue<Node> q = new LinkedList<Node>();
        // enqueue
        q.add(root);
        // traverse the queue
        while (!q.isEmpty()) {
            // dequeue
            Node p = q.poll();
            // print the Node by traverse Queue
            Visit(p);
            // duyet node left va kiem tra xem co null hay khong
            if (p.left != null) {// neu khong null, add vo ben trai
                q.add(p.left);
            }
            if (p.right != null) {
                q.add(p.right);// duyet right va check xem co null k, neu khong null, add vo ben phai
            }
        }
    }

    // Find the elem in the tree
    public void Search(Node p, int data) {
        if (p == null) {
            return;
        }
        Search(p.left, data);
        if (p.info.ID == data)
            Visit(p);
        Search(p.right, data);
    }
    // FInd to delete
    public Node Finds(int data) {
        if (root != null) {// check if root node is null
            return root.Find(data);// find data
        }
        return null;// if null, return null
    }
    // delete
    public void delete(Node p,int data){
        if(p==null){
            return;
        }
        Node toDel = Finds(data);
        if (toDel != null) {
            toDel.Delete();
        }
        PreOrder(root);
    }
    // get max
    int max(int a, int b){
        return (a>b) ? a:b;
    }
    //get parent node
    Node getParent(Node p, Node node){
        if(p == null){
            return null;
        }
        if(p.left == node || p.right == node){
            return p;
        }
        Node parent = getParent(p.left, node);
        if(parent == null){
            parent = getParent(p.right, node);
        }
        return parent;
    }
    // right rotation
    void rightRotate(Node p){
        Node left = p.left;
        if(left == null){
            return;
        }
        p.left = left.right;
        left.right = p;
        if(p == root){
            root = left;
        }else{
            Node q = getParent(root, p);
            if(p == q.right){
                q.right = left;
            }else{
                q.left = left;
            }
        }
    }
    // left rotation
    void leftRotate(Node p){
        Node right = p.right;
        if(right == null){
            return;
        }
        p.right = right.left;
        right.left = p;
        if(p == root){
            root = right;
        }else{
            Node q = getParent(root, p);
            if(p == q.right){
                q.right = right;
            }else{
                q.left = right;
            }
        }
    }
    // get height
    int getHeight(Node node){
        int height;
        if(node.right == null && node.left == null){
            height = 1;
        }else{
            if(node.right == null && node.left != null){
                height = getHeight(node.left) + 1;
            }else if(node.right != null && node.left ==  null){
                height = getHeight(node.right) + 1;
            }else{
                return max(getHeight(node.left), getHeight(node.right))+1;
            }
        }
        return height;
    }
    // get balance
    int getBalance(Node node){
        int balance;
        if(node.right == null && node.left == null){
            balance = 0;
        }else{
            if(node.right == null && node.left != null){
               balance = getHeight(node);
            }else if(node.right != null && node.left == null){
                balance = -getHeight(node);
            }else{
                return getHeight(node.left) - getHeight(node.right);
            }
        }
        return balance;
    }
    // re balance
    void ReBalance(Node p){
        int balance = getBalance(p);
        if(balance>=2){
            if(getBalance(p.left)>0){
                rightRotate(p);
            }else{
                leftRotate(p.left);
                rightRotate(p);
            }
        }else if(balance<=-2){
            if(getBalance(p.right)<0){
                leftRotate(p);
            }else{
                rightRotate(p.right);
                leftRotate(p);
            }
        }
    }
}
