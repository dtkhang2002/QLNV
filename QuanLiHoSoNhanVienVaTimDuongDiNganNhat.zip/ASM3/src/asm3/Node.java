package asm3;

public class Node {
    Person info;
    Node left, right;
    boolean isDeleted = false;
    public Node(Person data){
        info = data;
        left = right = null;
    }
   // add to the binary tree
   public void insert(Person data) {
    if(data.ID == this.info.ID){
        System.out.println("ID existed cannot add to the binary tree");
        return;
    }
    // check if ID Person added is greater than the current one
    if (data.ID > this.info.ID) { 
        if (this.right == null) {// check if the right of the tree is null or not
            this.right = new Node(data);// if null, the one added would be the first elem of the right of tree
        } else {
            this.right.insert(data);// if not null, insert recursively the elem to the right
        }
        // tuong tu khi lam voi ben trai
    } else if(data.ID < this.info.ID) {
        if (this.left == null) {
            this.left = new Node(data);
        } else {
            this.left.insert(data);
        }
    }
}
void Clear(){
    left = right = null;
}
// Find the nodes
public Node Find(int data){
    if (this.info.ID == data && !isDeleted) {
        return this;
    }
    if (data > this.info.ID && right != null) {
        return right.Find(data);
    }
    if (data < this.info.ID && left != null) {
        return left.Find(data);
    }
    return null;
}
public boolean isDeleted(){
    return isDeleted;// read the value of is deleted
}
public void Delete(){
    this.isDeleted = true;
}
}
