package asm3;

import java.util.Scanner;

public class MyPerson {
    MyBSTree tree;

    MyPerson() {
        tree = new MyBSTree();
    }

    public void Insert() {
        Person p = new Person();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap vao ID:");
        p.ID = scanner.nextInt();
        
            System.out.println("Nhap vao ten:");
            p.Name = scanner.next();
            System.out.println("Nhap vao ngay thang nam sinh:");
            p.DOB = scanner.next();
            System.out.println("Nhap vao noi sinh");
            p.Place = scanner.next();
            tree.Insert(new Person(p.ID, p.Name, p.DOB, p.Place));
    }

    public void InOrderTraverse() {
        tree.InOrder(tree.root);
    }

    public void PreorderTraverse() {
        tree.PreOrder(tree.root);
    }

    public void PostOrderTraverse() {
        tree.PostOrder(tree.root);
    }
    public void BreadthTraverse(){
        tree.Breadth();
    }
    public void Search(){
        int data;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input the ID want to find:");
        data = scanner.nextInt();
        if (tree.Finds(data) != null) {
            tree.Search(tree.root, data);
        } else {
            System.out.println("Person not existed");
        }
    }
    public void Deleted(){
        int data;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Inout the data want to delete:");
        data = scanner.nextInt();
        if (tree.Finds(data) != null) {
            tree.delete(tree.root, data);
        } else {
            System.out.println("Person not existed");
        }
    }
   public void UpdateBalance(){
       tree.ReBalance(tree.root);
   }

}
