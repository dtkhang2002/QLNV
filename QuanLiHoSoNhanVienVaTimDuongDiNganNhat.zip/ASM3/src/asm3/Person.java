package asm3;

public class Person {
    int ID;
    String Name, DOB, Place;

    Person() {

    }

    Person(int id, String name, String dob, String place) {
        ID = id;
        Name = name;
        DOB = dob;
        Place = place;
    }

    @Override

    public String toString() {

        return String.format("%-10s %-10s %-20s %-10s\n", ID, Name, DOB, Place);

    }
    
}
