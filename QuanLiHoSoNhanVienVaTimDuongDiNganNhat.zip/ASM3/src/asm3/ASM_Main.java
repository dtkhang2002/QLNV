package asm3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ASM_Main {
    public static void showMenu() {

        System.out.println("Choose one of this options:");

        System.out.println("Person Tree:");

        System.out.println("1. Insert a new Person.");

        System.out.println("2. In order traverse");

        System.out.println("3. Preorder traverse");

        System.out.println("4. Post order traverse");

        System.out.println("5. Breadth-First Traversal traverse");

        System.out.println("6.Search by Person ID");

        System.out.println("7. Delete by Person ID");

        System.out.println("8. Balancing Binary Search Tree ");

        System.out.println("9.  DFS_Graph");

        System.out.println("10. BFS_Graph");

        System.out.println("11.  Dijkstra");

        System.out.println("Exit:");

        System.out.println("0. Exit");

    }

    public static void main(String[] args) throws FileNotFoundException {
        MyPerson ms = new MyPerson();
        Graph g = new Graph();
        int[][] a = new int[7][7];
        try {
            File file = new File("MaTran.txt");
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            Scanner scanner = new Scanner(br);
            while (scanner.hasNextLine()) {
                for (int i = 0; i < a.length; i++) {
                    String[] line = scanner.nextLine().trim().split(" ");
                    for (int j = 0; j < line.length; j++) {
                        a[i][j] = Integer.parseInt(line[j]);
                    }
                }
            }
            g.setData(a);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int choice;
        Scanner scanner = new Scanner(System.in);
        while (true) {
            showMenu();
            System.out.println("Input your choice: ");
            choice = scanner.nextInt();
            System.out.println("Your choice: " + choice);
            if (choice == 0) {
                System.out.println("See you again");
                break;
            }
            switch (choice) {
                case 1:
                    ms.Insert();
                    break;
                case 2:
                    System.out.println("The tree after in order traverse:");
                    ms.InOrderTraverse();
                    break;
                case 3:
                    System.out.println("The tree after preorder traverse:");
                    ms.PreorderTraverse();
                    break;
                case 4:
                    System.out.println("The tree after post order traverse:");
                    ms.PostOrderTraverse();
                    break;
                case 5:
                    System.out.println("The tree after breadth traverse:");
                    ms.BreadthTraverse();
                    break;
                case 6:
                    ms.Search();
                    break;
                case 7:
                    ms.Deleted();
                    break;
                case 8:
                    ms.UpdateBalance();
                    System.out.println("Done");
                    break;
                case 9:
                    g.dispAdj();
                    System.out.println("\nEnter City number to start printing");
                    System.out.println("0: A | 1:B | 2:C | 3:D | 4:E | 5:F | 6:G");
                    int dfs = scanner.nextInt();
                    g.DFS(dfs);
                    System.out.println();
                    break;
                case 10:
                    g.dispAdj();
                    System.out.println("\nEnter City number to start printing");
                    System.out.println("0: A | 1:B | 2:C | 3:D | 4:E | 5:F | 6:G");
                    int bfs = scanner.nextInt();
                    g.BFS(bfs);
                    System.out.println();
                    break;
                case 11:
                    g.dispAdj();
                    System.out.println("\nEnter the starting point");
                    System.out.println("0: A | 1:B | 2:C | 3:D | 4:E | 5:F | 6:G");
                    int src = scanner.nextInt();
                    g.Dijkstra(a, 7, src, 4);
                    System.out.println();
                    break;
                default:
                    System.err.println("Please retype your choice again");
                    break;
            }
        }
    }
}
